var searchData=
[
  ['column_5fnames',['column_names',['../class_result_panel.html#a77880dc01d374e72346d28bb4fe03325',1,'ResultPanel']]],
  ['conc',['conc',['../class_author_search_parser.html#a17cec2d391f82dfd7ab53c0c3654a7c2',1,'AuthorSearchParser.conc()'],['../class_title_search_parser.html#a43d540fece41e75d5b7771f2f3823efa',1,'TitleSearchParser.conc()']]],
  ['custom_5frange',['custom_range',['../class_query1_panel.html#a30e14e3e964434cc0838a763c2d7c1ac',1,'Query1Panel']]]
];
