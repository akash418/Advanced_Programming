var searchData=
[
  ['getauthors',['getAuthors',['../class_publication.html#adc0668a777b148b958c0acb99364659b',1,'Publication']]],
  ['getauthorsearchresult',['GetAuthorSearchResult',['../class_get_author_search_result.html#af6550c27d53ea32c16278b0106d5f445',1,'GetAuthorSearchResult']]],
  ['getexactnames',['getExactNames',['../class_database.html#a3cfde376d87a7df9345beee4d90c2216',1,'Database']]],
  ['getnames',['getNames',['../class_person.html#a0d5276dc7a445d34e53f5dab2ffe5b72',1,'Person']]],
  ['getrelevantnames',['getRelevantNames',['../class_database.html#afa292ca6ec85b15dccfeab2a9919a812',1,'Database']]],
  ['getresult',['getResult',['../class_get_author_search_result.html#a4ffa6c3ea22847fa7e2715c2db98de39',1,'GetAuthorSearchResult.getResult()'],['../class_get_title_search_result.html#ad17500362cd892ab6125b20a947d6e25',1,'GetTitleSearchResult.getResult()'],['../class_result_database.html#a5fd3c924cb1d7c3895c36039172aebc4',1,'ResultDatabase.getResult()']]],
  ['getstringarray',['getStringArray',['../class_person.html#a1f8d820779b298d8e61afbd461ec92cd',1,'Person.getStringArray()'],['../class_publication.html#a7dccfd2e2afbc486ca1009eef07bf2cb',1,'Publication.getStringArray()']]],
  ['gettitle',['getTitle',['../class_publication.html#a891bc1dde6cb29a6bf32902d3bdec513',1,'Publication']]],
  ['gettitlesearchresult',['GetTitleSearchResult',['../class_get_title_search_result.html#a64e15559f2962e3cba79a0ca7c215051',1,'GetTitleSearchResult']]],
  ['getyear',['getYear',['../class_publication.html#aaa514255ccbfde6e1f8e54b4a53640bd',1,'Publication']]]
];
