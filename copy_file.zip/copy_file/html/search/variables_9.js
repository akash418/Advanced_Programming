var searchData=
[
  ['p',['P',['../class_author_search_parser.html#a39576950e7f66d8758c7d675d0c0b536',1,'AuthorSearchParser.P()'],['../class_title_search_parser.html#a82138409657d3d5889c3ea9e75e42105',1,'TitleSearchParser.P()']]],
  ['pages',['pages',['../class_publication.html#afc0306e0f47ec5ecbee27457f56d0d49',1,'Publication']]],
  ['perresult',['PerResult',['../class_result_panel.html#a11270237c7d38dd2bf5a33513891b88f',1,'ResultPanel']]],
  ['persons',['Persons',['../class_database.html#a0c27d8f8efd6981830b36a371d037b73',1,'Database']]],
  ['pubauthors',['pubAuthors',['../class_d_b_l_p___parser.html#aef53ab37856a981043ae326eb3524fc5',1,'DBLP_Parser']]],
  ['pubresult',['PubResult',['../class_result_panel.html#a414cd0e905d7084a9219843faa7ebadc',1,'ResultPanel']]]
];
