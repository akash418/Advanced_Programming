var searchData=
[
  ['person_2ejava',['Person.java',['../_person_8java.html',1,'']]],
  ['publication_2ejava',['Publication.java',['../_publication_8java.html',1,'']]],
  ['publicationrelevancecomparator_2ejava',['PublicationRelevanceComparator.java',['../_publication_relevance_comparator_8java.html',1,'']]],
  ['publicationyearcomparator_2ejava',['PublicationYearComparator.java',['../_publication_year_comparator_8java.html',1,'']]]
];
