var searchData=
[
  ['year',['year',['../class_publication.html#aa74978f065d5f8d77e86dc74e2627a7a',1,'Publication']]],
  ['year_5fof_5fprediction',['year_of_prediction',['../class_query3_panel.html#a0490008637e0705ab70cc4648a21f0d8',1,'Query3Panel']]],
  ['year_5fsince',['year_since',['../class_query1_panel.html#a4105c6c914cf083296035a9e2a38b392',1,'Query1Panel']]],
  ['yearradio',['yearRadio',['../class_query1_panel.html#ad0109b8e53b0b81f1feb25d950698b3c',1,'Query1Panel']]]
];
