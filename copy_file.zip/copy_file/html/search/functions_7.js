var searchData=
[
  ['reset',['Reset',['../class_result_panel.html#a90a78a6361b54469d5add8108bdb402f',1,'ResultPanel']]],
  ['resultpanel',['ResultPanel',['../class_result_panel.html#a1f0864074da52caf14581a14b2574d48',1,'ResultPanel']]],
  ['righttitle',['RightTitle',['../class_author_search_parser.html#a1fdb060a670982c5d625b7b24a67ce8e',1,'AuthorSearchParser.RightTitle()'],['../class_title_search_parser.html#a9c240859ff120802d08e0cf684cc8e1e',1,'TitleSearchParser.RightTitle()']]]
];
