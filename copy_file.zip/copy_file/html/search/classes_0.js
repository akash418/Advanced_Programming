var searchData=
[
  ['authorsearchparser',['AuthorSearchParser',['../class_author_search_parser.html',1,'']]]
];
