var searchData=
[
  ['volume',['volume',['../class_publication.html#acab78dec8eecbde82003f7b84326e285',1,'Publication']]]
];
