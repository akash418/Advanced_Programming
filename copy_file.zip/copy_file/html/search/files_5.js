var searchData=
[
  ['query1panel_2ejava',['Query1Panel.java',['../_query1_panel_8java.html',1,'']]],
  ['query2panel_2ejava',['Query2Panel.java',['../_query2_panel_8java.html',1,'']]],
  ['query3panel_2ejava',['Query3Panel.java',['../_query3_panel_8java.html',1,'']]]
];
