var searchData=
[
  ['predict',['Predict',['../class_query3_panel.html#ae7b688ba9d037adc590956ac6fcbd13b',1,'Query3Panel']]],
  ['predictnext',['predictNext',['../class_query3_panel.html#acb4bdefa3edac3a2d6146132be1e3a8c',1,'Query3Panel']]]
];
