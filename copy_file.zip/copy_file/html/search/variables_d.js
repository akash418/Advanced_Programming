var searchData=
[
  ['table',['table',['../class_result_panel.html#a7efcc61cd33b439bb4a4ce365a05fcd9',1,'ResultPanel']]],
  ['title',['Title',['../class_publication.html#a58030ff18aa04a396a36de1fbcbe3f1d',1,'Publication']]],
  ['titletag',['titleTag',['../class_title_search_parser.html#a2559d5f428289c877c63d224d0d22621',1,'TitleSearchParser']]],
  ['tpanel',['tPanel',['../class_result_panel.html#a6e9ad244def5b4e8ab98c846f5054b5b',1,'ResultPanel']]]
];
