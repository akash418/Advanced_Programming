var searchData=
[
  ['characters',['characters',['../class_author_search_parser.html#a4ffda3a2a785a2726263ba5e67c80e2c',1,'AuthorSearchParser.characters()'],['../class_d_b_l_p___parser.html#a02ab9b42974ac5db4bffe5162fc80fd6',1,'DBLP_Parser.characters()'],['../class_title_search_parser.html#a1b2334fc06b6fe4bfa5b13a690bb5b70',1,'TitleSearchParser.characters()']]],
  ['column_5fnames',['column_names',['../class_result_panel.html#a77880dc01d374e72346d28bb4fe03325',1,'ResultPanel']]],
  ['compare',['compare',['../class_publication_relevance_comparator.html#a3974b2a7641d77b24a7519fab13a37bf',1,'PublicationRelevanceComparator.compare()'],['../class_publication_year_comparator.html#a4332c46417a270eeb76e1f12332882ec',1,'PublicationYearComparator.compare()']]],
  ['comparerel',['compareRel',['../class_publication.html#a40998665fe8b81a3b04ba63939c3b6fb',1,'Publication']]],
  ['compareyear',['compareYear',['../class_publication.html#a0a2794c941ecbe871beebd6a253c32a7',1,'Publication']]],
  ['conc',['conc',['../class_author_search_parser.html#a17cec2d391f82dfd7ab53c0c3654a7c2',1,'AuthorSearchParser.conc()'],['../class_title_search_parser.html#a43d540fece41e75d5b7771f2f3823efa',1,'TitleSearchParser.conc()']]],
  ['custom_5frange',['custom_range',['../class_query1_panel.html#a30e14e3e964434cc0838a763c2d7c1ac',1,'Query1Panel']]]
];
