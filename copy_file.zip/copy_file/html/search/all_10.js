var searchData=
[
  ['whichresult',['whichResult',['../class_result_panel.html#afdfc4b52525f23436c73da3e4e2219d9',1,'ResultPanel']]]
];
