var searchData=
[
  ['getauthorsearchresult_2ejava',['GetAuthorSearchResult.java',['../_get_author_search_result_8java.html',1,'']]],
  ['gettitlesearchresult_2ejava',['GetTitleSearchResult.java',['../_get_title_search_result_8java.html',1,'']]]
];
