var searchData=
[
  ['search_5ftype',['search_type',['../class_query1_panel.html#a12848f467cc67adfe5c80e74eb0e404f',1,'Query1Panel']]],
  ['searchbutton',['SearchButton',['../class_query1_panel.html#aca1b343e12e8adbf180000ec7e0e6a35',1,'Query1Panel.SearchButton()'],['../class_query2_panel.html#a3bd664e25dffa2f0be39593d719d0313',1,'Query2Panel.SearchButton()'],['../class_query3_panel.html#a770afc3e9ea159394fd729a5c4ab2260',1,'Query3Panel.SearchButton()']]],
  ['searchby',['searchby',['../class_query1_panel.html#a18ff5e03d177c3a9f7946ccac91c5e3c',1,'Query1Panel']]],
  ['serialversionuid',['serialVersionUID',['../class_main_frame.html#a5cce4971d3e0bd809b9dcdcfeb03eb13',1,'MainFrame.serialVersionUID()'],['../class_query1_panel.html#a87d4f501cb00c122eac8cb8a514dba81',1,'Query1Panel.serialVersionUID()'],['../class_query2_panel.html#a082d2870d345df6c11d5333dc6875cb2',1,'Query2Panel.serialVersionUID()'],['../class_query3_panel.html#aa6069c1a126f265ac0708c5e5d3150ac',1,'Query3Panel.serialVersionUID()'],['../class_result_panel.html#ad45232238d3b72353afc8003bb5ba2f4',1,'ResultPanel.serialVersionUID()']]],
  ['sno',['SNo',['../class_result_panel.html#ad1280c9755c11dcbc5e152dc51dfa9be',1,'ResultPanel']]],
  ['sr_5fcustom_5ffrom',['sr_custom_from',['../class_query1_panel.html#a4623275f8dbb01c5c9fb0047d79f77a2',1,'Query1Panel']]],
  ['sr_5fcustom_5ftill',['sr_custom_till',['../class_query1_panel.html#a009f93a21cafb82ccf7de2ce07e880ec',1,'Query1Panel']]],
  ['sr_5fname_5ftitle',['sr_name_title',['../class_query1_panel.html#a33086d180a52e17d93d9817ab7c0ba47',1,'Query1Panel']]],
  ['sr_5fnoofpub',['sr_noOfPub',['../class_query2_panel.html#aa4446ba83a9c234d67e91448cd2ead57',1,'Query2Panel']]],
  ['sr_5fyear_5fsince',['sr_year_since',['../class_query1_panel.html#a5d7785457c6202f5f9d6386ca1b783e0',1,'Query1Panel']]]
];
