var searchData=
[
  ['journal',['journal',['../class_publication.html#afae977fe83d1f72643b6d744dc1c4829',1,'Publication']]]
];
