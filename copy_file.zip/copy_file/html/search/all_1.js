var searchData=
[
  ['banner',['Banner',['../class_main_frame.html#ac5a5d7f2b2e89d80337c0a1c64ce497b',1,'MainFrame']]],
  ['bauthors',['bAuthors',['../class_author_search_parser.html#a7daea8b0fad915ed5c1b682c6edcbc08',1,'AuthorSearchParser.bAuthors()'],['../class_d_b_l_p___parser.html#a63c96b129a67fe13f1c75850a857c445',1,'DBLP_Parser.bAuthors()'],['../class_title_search_parser.html#a43b35176cdbcb8bd2ad418f23bb741fc',1,'TitleSearchParser.bAuthors()']]],
  ['bg',['bg',['../class_query1_panel.html#afb8cd92b645eed103cab83aaa189c4c2',1,'Query1Panel']]],
  ['bjournal',['bJournal',['../class_author_search_parser.html#a4edaa46f102b39557abac9da59e65496',1,'AuthorSearchParser.bJournal()'],['../class_title_search_parser.html#a04566ba874c525b12d4312c9d0946955',1,'TitleSearchParser.bJournal()']]],
  ['bpages',['bPages',['../class_author_search_parser.html#a27e4f3d0f00b97870eccfec93f7aaa0f',1,'AuthorSearchParser.bPages()'],['../class_title_search_parser.html#a1cbd192c5860a3c0b455102794ca2720',1,'TitleSearchParser.bPages()']]],
  ['btitle',['bTitle',['../class_author_search_parser.html#afb7994b1b2f2d45fbe94472e671ef903',1,'AuthorSearchParser.bTitle()'],['../class_title_search_parser.html#acfa01c71c6dc1571cdf4a46695ced7d4',1,'TitleSearchParser.bTitle()']]],
  ['burl',['bURL',['../class_author_search_parser.html#a1580b31dfc872a3fc518ee184b35ee47',1,'AuthorSearchParser.bURL()'],['../class_title_search_parser.html#a38351414f3b264a21a3c36dde88ae3f6',1,'TitleSearchParser.bURL()']]],
  ['bvolume',['bVolume',['../class_author_search_parser.html#add4101618cad83177a1c67d3af897843',1,'AuthorSearchParser.bVolume()'],['../class_title_search_parser.html#ae6de6a951c0c7ea95c86cf5c94ad01dd',1,'TitleSearchParser.bVolume()']]],
  ['byear',['bYear',['../class_author_search_parser.html#a41f4306162abad7becd43c7d6508e8c8',1,'AuthorSearchParser.bYear()'],['../class_title_search_parser.html#ab622b84b93897133bfacc3c7892c5e22',1,'TitleSearchParser.bYear()']]]
];
