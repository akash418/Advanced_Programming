var searchData=
[
  ['aut',['aut',['../class_d_b_l_p___parser.html#ad373951313a49c332cc5b13a375d0a7b',1,'DBLP_Parser']]],
  ['author_5fname',['author_name',['../class_query3_panel.html#a178addd9297594b40062d71e2745b1bc',1,'Query3Panel']]],
  ['authors',['Authors',['../class_publication.html#addf77c5b656092b2040e2c6cddb42e8c',1,'Publication']]],
  ['auttono',['autToNo',['../class_database.html#ad79937f03ff479b4fd35e15682292b50',1,'Database']]]
];
