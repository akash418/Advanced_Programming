var searchData=
[
  ['name_5ftitle',['name_title',['../class_query1_panel.html#a851fd1dd96bdc23d98668666d8dd6402',1,'Query1Panel']]],
  ['names',['Names',['../class_person.html#a08f1245283f18c567d5c0d0ae8a458b4',1,'Person']]],
  ['newauthor',['newAuthor',['../class_d_b_l_p___parser.html#a598f8ad0170d6ccc34106587ea28116b',1,'DBLP_Parser']]],
  ['next',['Next',['../class_result_panel.html#a84d7930da623fc6d5c942f054548e5a0',1,'ResultPanel']]],
  ['noofpub',['noOfPub',['../class_query2_panel.html#a59267fccbf1167ec2a6cf5cb1109897a',1,'Query2Panel']]],
  ['noofresults',['NoOfResults',['../class_result_panel.html#a693119c62a4ba3296cd8fbd9ee973ed4',1,'ResultPanel']]]
];
