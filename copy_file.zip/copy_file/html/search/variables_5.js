var searchData=
[
  ['gbc',['gbc',['../class_query1_panel.html#a00c140dec21a9c30b314a4ff7c0ca27c',1,'Query1Panel.gbc()'],['../class_query2_panel.html#ac5841aad547ce7ac5f3e6a7f7e158145',1,'Query2Panel.gbc()'],['../class_query3_panel.html#acda98e9708552f438939fb7c299ea24c',1,'Query3Panel.gbc()'],['../class_result_panel.html#a50cb82d38fb1b7547fa7ec900d4c4e2e',1,'ResultPanel.gbc()']]]
];
