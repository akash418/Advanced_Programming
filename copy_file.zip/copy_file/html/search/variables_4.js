var searchData=
[
  ['exrel',['ExRel',['../class_publication.html#a5d9a1cc356a1773657ed1b3b6c6cc79a',1,'Publication']]],
  ['exsprel',['ExSpRel',['../class_publication.html#ab04170dcb9d3062c0626678f78bf4fe4',1,'Publication']]]
];
