var searchData=
[
  ['table',['table',['../class_result_panel.html#a7efcc61cd33b439bb4a4ce365a05fcd9',1,'ResultPanel']]],
  ['title',['Title',['../class_publication.html#a58030ff18aa04a396a36de1fbcbe3f1d',1,'Publication']]],
  ['titlesearchparser',['TitleSearchParser',['../class_title_search_parser.html',1,'TitleSearchParser'],['../class_title_search_parser.html#abbfb3529a260d1a97fd97a825c0ad063',1,'TitleSearchParser.TitleSearchParser()']]],
  ['titlesearchparser_2ejava',['TitleSearchParser.java',['../_title_search_parser_8java.html',1,'']]],
  ['titletag',['titleTag',['../class_title_search_parser.html#a2559d5f428289c877c63d224d0d22621',1,'TitleSearchParser']]],
  ['tpanel',['tPanel',['../class_result_panel.html#a6e9ad244def5b4e8ab98c846f5054b5b',1,'ResultPanel']]]
];
