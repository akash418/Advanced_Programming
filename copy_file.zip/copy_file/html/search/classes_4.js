var searchData=
[
  ['person',['Person',['../class_person.html',1,'']]],
  ['publication',['Publication',['../class_publication.html',1,'']]],
  ['publicationrelevancecomparator',['PublicationRelevanceComparator',['../class_publication_relevance_comparator.html',1,'']]],
  ['publicationyearcomparator',['PublicationYearComparator',['../class_publication_year_comparator.html',1,'']]]
];
