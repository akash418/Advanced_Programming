var searchData=
[
  ['endelement',['endElement',['../class_author_search_parser.html#af1aca97d0d9e170d0eeb1ef0432cc86b',1,'AuthorSearchParser.endElement()'],['../class_d_b_l_p___parser.html#ad33d61b78dd82436bf08eea9e92ef9b3',1,'DBLP_Parser.endElement()'],['../class_title_search_parser.html#af56263a2f184abb104074d4325b5113a',1,'TitleSearchParser.endElement()']]],
  ['exrel',['ExRel',['../class_publication.html#a5d9a1cc356a1773657ed1b3b6c6cc79a',1,'Publication']]],
  ['exsprel',['ExSpRel',['../class_publication.html#ab04170dcb9d3062c0626678f78bf4fe4',1,'Publication']]]
];
