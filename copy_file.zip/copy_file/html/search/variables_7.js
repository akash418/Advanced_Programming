var searchData=
[
  ['mainpanel',['MainPanel',['../class_main_frame.html#a0cf6eeafcf08fdcd9f8ca9b18d939eac',1,'MainFrame']]]
];
