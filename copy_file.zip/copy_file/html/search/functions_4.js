var searchData=
[
  ['main',['main',['../class_main.html#a8a5d0f827edddff706cc0e6740d0579a',1,'Main']]],
  ['mainframe',['MainFrame',['../class_main_frame.html#a6c803d556adfa5c53a5b24aedb2fef4d',1,'MainFrame']]]
];
