var searchData=
[
  ['getauthorsearchresult',['GetAuthorSearchResult',['../class_get_author_search_result.html',1,'']]],
  ['gettitlesearchresult',['GetTitleSearchResult',['../class_get_title_search_result.html',1,'']]]
];
