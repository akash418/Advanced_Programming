var searchData=
[
  ['url',['url',['../class_publication.html#ae1c59b8b8ca7e384886958cf400452a2',1,'Publication']]]
];
