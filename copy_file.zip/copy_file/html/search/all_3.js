var searchData=
[
  ['data',['data',['../class_result_panel.html#a5ebaeb7eb4a5bd303a8ad7bf8f47b930',1,'ResultPanel']]],
  ['database',['Database',['../class_database.html',1,'']]],
  ['database_2ejava',['Database.java',['../_database_8java.html',1,'']]],
  ['db',['DB',['../class_main_frame.html#aa6745a460064dc158af98327b218aa20',1,'MainFrame.DB()'],['../class_query1_panel.html#ae7fd3a51acee79c946c4cade7208e763',1,'Query1Panel.DB()'],['../class_query2_panel.html#a88523ebfcaf899e0d220a936db9eb02d',1,'Query2Panel.DB()'],['../class_query3_panel.html#a4824112c8406eb6a12f7dffe638fd6d5',1,'Query3Panel.DB()']]],
  ['dblp_5fparser',['DBLP_Parser',['../class_d_b_l_p___parser.html',1,'']]],
  ['dblp_5fparser_2ejava',['DBLP_Parser.java',['../_d_b_l_p___parser_8java.html',1,'']]]
];
