var searchData=
[
  ['query1panel',['Query1Panel',['../class_query1_panel.html',1,'']]],
  ['query2panel',['Query2Panel',['../class_query2_panel.html',1,'']]],
  ['query3panel',['Query3Panel',['../class_query3_panel.html',1,'']]]
];
